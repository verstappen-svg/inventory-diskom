<?php

namespace App\Http\Controllers;

use App\Models\SoftwareAsset;
use App\Models\VerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VerificationController extends Controller
{
    /**
     * =========================================================
     * HALAMAN VERIFIKASI
     * =========================================================
     */
    public function index(Request $request)
    {
        /*
        |--------------------------------------------------------------------------
        | FILTER
        |--------------------------------------------------------------------------
        */

        $jenisPengajuan = $request->input('jenis_pengajuan');
        $kategori = $request->input('kategori');
        $status = $request->input('status');


        /*
        |--------------------------------------------------------------------------
        | QUERY PENGAJUAN
        |--------------------------------------------------------------------------
        */

        $query = VerificationRequest::with([
            'submitter',
            'verifier',
        ])->latest();


        /*
        |--------------------------------------------------------------------------
        | FILTER JENIS PENGAJUAN
        |--------------------------------------------------------------------------
        */

        if (
            $jenisPengajuan &&
            in_array($jenisPengajuan, [
                'create',
                'update',
                'delete',
            ])
        ) {
            $query->where(
                'action',
                $jenisPengajuan
            );
        }


        /*
        |--------------------------------------------------------------------------
        | FILTER KATEGORI
        |--------------------------------------------------------------------------
        */

        if ($kategori) {
            $query->where(
                'module',
                $kategori
            );
        }


        /*
        |--------------------------------------------------------------------------
        | FILTER STATUS
        |--------------------------------------------------------------------------
        */

        if (
            $status &&
            in_array($status, [
                'menunggu',
                'disetujui',
                'ditolak',
            ])
        ) {
            $query->where(
                'status',
                $status
            );
        }


        /*
        |--------------------------------------------------------------------------
        | DATA
        |--------------------------------------------------------------------------
        */

        $requests = $query->get();


        /*
        |--------------------------------------------------------------------------
        | STATISTIK
        |--------------------------------------------------------------------------
        */

        $menunggu = VerificationRequest::where(
            'status',
            'menunggu'
        )->count();

        $disetujui = VerificationRequest::where(
            'status',
            'disetujui'
        )->count();

        $ditolak = VerificationRequest::where(
            'status',
            'ditolak'
        )->count();


        /*
        |--------------------------------------------------------------------------
        | PILIHAN KATEGORI
        |--------------------------------------------------------------------------
        */

        $kategoriOptions = [
            'software'    => 'Software',
            'hardware'    => 'Hardware',
            'jaringan'    => 'Jaringan',
            'data-center' => 'Data Center',
            'data_center' => 'Data Center',
            'splp'        => 'SPLP',
            'data'        => 'Data',
            'sdm'         => 'SDM',
        ];


        /*
        |--------------------------------------------------------------------------
        | VIEW
        |--------------------------------------------------------------------------
        */

        return view(
            'verifikasi.index',
            compact(
                'requests',
                'menunggu',
                'disetujui',
                'ditolak',
                'jenisPengajuan',
                'kategori',
                'status',
                'kategoriOptions'
            )
        );
    }


    /**
     * =========================================================
     * APPROVE
     * =========================================================
     */
    public function approve(
        Request $request,
        VerificationRequest $verificationRequest
    ) {
        /*
        |--------------------------------------------------------------------------
        | HARUS MASIH MENUNGGU
        |--------------------------------------------------------------------------
        */

        if (!$verificationRequest->isPending()) {
            return back()->with(
                'error',
                'Pengajuan ini sudah diproses sebelumnya.'
            );
        }


        try {

            DB::transaction(function () use (
                $verificationRequest
            ) {

                /*
                |--------------------------------------------------------------------------
                | SOFTWARE
                |--------------------------------------------------------------------------
                */

                if (
                    $verificationRequest->module === 'software'
                ) {

                    $this->approveSoftware(
                        $verificationRequest
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | UPDATE STATUS REQUEST
                |--------------------------------------------------------------------------
                */

                $verificationRequest->update([
                    'status' => 'disetujui',
                    'verified_by' => auth()->id(),
                    'verified_at' => now(),
                    'rejection_reason' => null,
                ]);
            });


            return back()->with(
                'success',
                'Pengajuan berhasil disetujui.'
            );

        } catch (\Throwable $e) {

            return back()->with(
                'error',
                'Pengajuan gagal disetujui: ' .
                $e->getMessage()
            );
        }
    }


    /**
     * =========================================================
     * APPROVE SOFTWARE
     * =========================================================
     */
    private function approveSoftware(
        VerificationRequest $verificationRequest
    ): void {

        /*
        |--------------------------------------------------------------------------
        | CARI DATA
        |--------------------------------------------------------------------------
        */

        $software = SoftwareAsset::find(
            $verificationRequest->record_id
        );


        /*
        |--------------------------------------------------------------------------
        | TAMBAH
        |--------------------------------------------------------------------------
        */

        if (
            $verificationRequest->action === 'create'
        ) {

            if (!$software) {
                throw new \Exception(
                    'Data software tidak ditemukan.'
                );
            }

            $software->update([
                'verifikasi' => 'disetujui',
                'komentar' => null,
            ]);

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | PERBARUI
        |--------------------------------------------------------------------------
        */

        if (
            $verificationRequest->action === 'update'
        ) {

            if (!$software) {
                throw new \Exception(
                    'Data software tidak ditemukan.'
                );
            }

            $software->update([
                'verifikasi' => 'disetujui',
                'komentar' => null,
            ]);

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | PENGHAPUSAN
        |--------------------------------------------------------------------------
        */

        if (
            $verificationRequest->action === 'delete'
        ) {

            /*
            |--------------------------------------------------------------------------
            | Kalau data masih ada
            |--------------------------------------------------------------------------
            |
            | Ini kondisi normal untuk request penghapusan baru.
            |
            */

            if ($software) {

                $software->delete();

                return;
            }


            /*
            |--------------------------------------------------------------------------
            | Kalau data sudah tidak ada
            |--------------------------------------------------------------------------
            |
            | Ini untuk menangani request penghapusan lama
            | yang record-nya sudah terhapus sebelumnya.
            |
            | Tidak perlu error.
            |
            */

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | AKSI TIDAK DIKENALI
        |--------------------------------------------------------------------------
        */

        throw new \Exception(
            'Jenis pengajuan software tidak dikenali.'
        );
    }


    /**
     * =========================================================
     * REJECT
     * =========================================================
     */
    public function reject(
        Request $request,
        VerificationRequest $verificationRequest
    ) {

        /*
        |--------------------------------------------------------------------------
        | HARUS MASIH MENUNGGU
        |--------------------------------------------------------------------------
        */

        if (!$verificationRequest->isPending()) {
            return back()->with(
                'error',
                'Pengajuan ini sudah diproses sebelumnya.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | VALIDASI ALASAN
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([
            'rejection_reason' => [
                'required',
                'string',
                'max:1000',
            ],
        ], [
            'rejection_reason.required' =>
                'Alasan penolakan wajib diisi.',
        ]);


        try {

            DB::transaction(function () use (
                $verificationRequest,
                $validated
            ) {

                /*
                |--------------------------------------------------------------------------
                | SOFTWARE
                |--------------------------------------------------------------------------
                */

                if (
                    $verificationRequest->module === 'software'
                ) {

                    $this->rejectSoftware(
                        $verificationRequest,
                        $validated['rejection_reason']
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | UPDATE REQUEST
                |--------------------------------------------------------------------------
                */

                $verificationRequest->update([
                    'status' => 'ditolak',
                    'verified_by' => auth()->id(),
                    'verified_at' => now(),
                    'rejection_reason' =>
                        $validated['rejection_reason'],
                ]);
            });


            return back()->with(
                'success',
                'Pengajuan berhasil ditolak.'
            );

        } catch (\Throwable $e) {

            return back()->with(
                'error',
                'Pengajuan gagal ditolak: ' .
                $e->getMessage()
            );
        }
    }


    /**
     * =========================================================
     * REJECT SOFTWARE
     * =========================================================
     */
    private function rejectSoftware(
        VerificationRequest $verificationRequest,
        string $reason
    ): void {

        /*
        |--------------------------------------------------------------------------
        | CARI DATA
        |--------------------------------------------------------------------------
        */

        $software = SoftwareAsset::find(
            $verificationRequest->record_id
        );


        /*
        |--------------------------------------------------------------------------
        | TAMBAH / PERBARUI
        |--------------------------------------------------------------------------
        */

        if (
            $verificationRequest->action === 'create' ||
            $verificationRequest->action === 'update'
        ) {

            if (!$software) {
                throw new \Exception(
                    'Data software tidak ditemukan.'
                );
            }

            $software->update([
                'verifikasi' => 'ditolak',
                'komentar' => $reason,
            ]);

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | PENGHAPUSAN DITOLAK
        |--------------------------------------------------------------------------
        */

        if (
            $verificationRequest->action === 'delete'
        ) {

            /*
            |--------------------------------------------------------------------------
            | Kalau data masih ada
            |--------------------------------------------------------------------------
            |
            | Data tetap ada.
            | Status menjadi ditolak.
            |
            */

            if ($software) {

                $software->update([
                    'verifikasi' => 'ditolak',
                    'komentar' => $reason,
                ]);

                return;
            }


            /*
            |--------------------------------------------------------------------------
            | Kalau data sudah tidak ada
            |--------------------------------------------------------------------------
            |
            | Request lama.
            | Tidak bisa mengembalikan record otomatis
            | karena data fisiknya memang sudah terhapus.
            |
            */

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | AKSI TIDAK DIKENALI
        |--------------------------------------------------------------------------
        */

        throw new \Exception(
            'Jenis pengajuan software tidak dikenali.'
        );
    }
}